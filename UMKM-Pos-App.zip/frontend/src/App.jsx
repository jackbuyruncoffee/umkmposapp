import React from 'react';
import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Routes>
      <Route path="/" element={<div className="text-green-600 text-center mt-10 font-bold text-xl">Welcome to UMKM Pos App</div>} />
    </Routes>
  );
}

export default App;